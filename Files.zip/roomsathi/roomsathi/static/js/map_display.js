
document.addEventListener("DOMContentLoaded", function () {

    var el = document.getElementById("map-display");

    if (!el) return;

    var lat = parseFloat(el.dataset.lat);
    var lng = parseFloat(el.dataset.lng);

    if (isNaN(lat) || isNaN(lng)) return;

    var map = L.map(el).setView([lat, lng], 15);

    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: "&copy; OpenStreetMap contributors"
    }).addTo(map);

    L.marker([lat, lng]).addTo(map);
});