
document.addEventListener("DOMContentLoaded", function () {

    const el = document.getElementById("map-picker");

   
    if (!el) {
        return;
    }

    const latInput = document.getElementById("id_latitude");
    const lngInput = document.getElementById("id_longitude");
    const status = document.getElementById("geo-status");
    const locationButton = document.getElementById("use-location");

    
    if (!latInput || !lngInput) {
        console.error("RoomSathi: Latitude or Longitude field not found.");
        return;
    }

    
    const lat = parseFloat(latInput.value);
    const lng = parseFloat(lngInput.value);

    const hasPoint = !isNaN(lat) && !isNaN(lng);

    
    const defaultLatitude = 27.7006;
    const defaultLongitude = 83.4484;

    
    const map = L.map("map-picker").setView(
        hasPoint
            ? [lat, lng]
            : [defaultLatitude, defaultLongitude],
        hasPoint ? 15 : 12
    );

    
    L.tileLayer(
        "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png",
        {
            attribution:
                '&copy; OpenStreetMap contributors &copy; CARTO',
            subdomains: "abcd",
            maxZoom: 20
        }
    ).addTo(map);

    
    let marker = null;

    if (hasPoint) {
        marker = L.marker([lat, lng]).addTo(map);
    }

    
    function setPoint(latitude, longitude) {

        
        latInput.value = latitude.toFixed(6);
        lngInput.value = longitude.toFixed(6);

        
        if (marker) {

            marker.setLatLng([
                latitude,
                longitude
            ]);

        } else {

            marker = L.marker([
                latitude,
                longitude
            ]).addTo(map);
        }

        // Update status text
        if (status) {
            status.textContent =
                "Selected: " +
                latitude.toFixed(5) +
                ", " +
                longitude.toFixed(5);
        }
    }

    
    if (hasPoint && status) {

        status.textContent =
            "Selected: " +
            lat.toFixed(5) +
            ", " +
            lng.toFixed(5);
    }

    // Click anywhere on map
    map.on("click", function (event) {

        const latitude = event.latlng.lat;
        const longitude = event.latlng.lng;

        setPoint(
            latitude,
            longitude
        );
    });

    
    if (locationButton) {

        locationButton.addEventListener(
            "click",
            function () {

               
                if (!navigator.geolocation) {

                    alert(
                        "Geolocation is not supported by your browser."
                    );

                    return;
                }

                
                if (status) {
                    status.textContent =
                        "Getting your location...";
                }

                // Get current location
                navigator.geolocation.getCurrentPosition(

                    function (position) {

                        const latitude =
                            position.coords.latitude;

                        const longitude =
                            position.coords.longitude;

                        // Set marker and form fields
                        setPoint(
                            latitude,
                            longitude
                        );

                        // Move map to current location
                        map.setView(
                            [
                                latitude,
                                longitude
                            ],
                            16
                        );
                    },

                    function (error) {

                        console.error(
                            "Geolocation error:",
                            error
                        );

                        if (status) {
                            status.textContent =
                                "Could not get your location. Click the map instead.";
                        }
                    },

                    {
                        enableHighAccuracy: true,
                        timeout: 10000,
                        maximumAge: 0
                    }
                );
            }
        );
    }

   
    setTimeout(function () {
        map.invalidateSize();
    }, 300);

});