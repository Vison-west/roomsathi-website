// RoomSathi maps (Leaflet)
// ------------------------------------------------------------------
// This one file handles both kinds of map on the site:
//   1. #map-display -> read-only map on room / roommate detail pages
//   2. #map-picker  -> clickable map on the "post a room" and
//                      "roommate post" forms (fills latitude/longitude)
//
// Map tiles come from OpenStreetMap. Its tile server blocks requests
// that don't say which website they come from (the "Referer" header),
// showing "Access blocked". SECURE_REFERRER_POLICY in settings.py makes
// the browser send that header, so the tiles load.
// ------------------------------------------------------------------

// Default map centre when nothing is selected yet: Butwal, Nepal
var DEFAULT_CENTER = [27.7006, 83.4484];

// Create a Leaflet map with the background tiles added
function makeMap(element, center, zoom) {
    var map = L.map(element).setView(center, zoom);

    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19
    }).addTo(map);

    // Fixes grey/partly drawn maps when the page layout settles late
    setTimeout(function () { map.invalidateSize(); }, 300);
    return map;
}

document.addEventListener("DOMContentLoaded", function () {

    // ---------- 1. Read-only map on detail pages ----------
    var displayEl = document.getElementById("map-display");
    if (displayEl) {
        var lat = parseFloat(displayEl.dataset.lat);
        var lng = parseFloat(displayEl.dataset.lng);
        if (!isNaN(lat) && !isNaN(lng)) {
            var displayMap = makeMap(displayEl, [lat, lng], 15);
            L.marker([lat, lng]).addTo(displayMap);
        }
    }

    // ---------- 2. Location picker on forms ----------
    var pickerEl = document.getElementById("map-picker");
    if (!pickerEl) return;

    var latInput = document.getElementById("id_latitude");
    var lngInput = document.getElementById("id_longitude");
    var status = document.getElementById("geo-status");
    var locationButton = document.getElementById("use-location");

    if (!latInput || !lngInput) {
        console.error("RoomSathi: Latitude or Longitude field not found.");
        return;
    }

    // If the form already has coordinates (edit page), start there
    var startLat = parseFloat(latInput.value);
    var startLng = parseFloat(lngInput.value);
    var hasPoint = !isNaN(startLat) && !isNaN(startLng);

    var map = makeMap(pickerEl, hasPoint ? [startLat, startLng] : DEFAULT_CENTER, hasPoint ? 15 : 12);
    var marker = hasPoint ? L.marker([startLat, startLng]).addTo(map) : null;

    function showStatus(latitude, longitude) {
        if (status) {
            status.textContent = "Selected: " + latitude.toFixed(5) + ", " + longitude.toFixed(5);
        }
    }

    // Save a point into the form fields and move the marker there
    function setPoint(latitude, longitude) {
        latInput.value = latitude.toFixed(6);
        lngInput.value = longitude.toFixed(6);
        if (marker) {
            marker.setLatLng([latitude, longitude]);
        } else {
            marker = L.marker([latitude, longitude]).addTo(map);
        }
        showStatus(latitude, longitude);
    }

    if (hasPoint) showStatus(startLat, startLng);

    // Click anywhere on the map to choose the location
    map.on("click", function (event) {
        setPoint(event.latlng.lat, event.latlng.lng);
    });

    // "Use My Current Location" button
    if (locationButton) {
        locationButton.addEventListener("click", function () {
            if (!navigator.geolocation) {
                alert("Geolocation is not supported by your browser.");
                return;
            }
            if (status) status.textContent = "Getting your location...";

            navigator.geolocation.getCurrentPosition(
                function (position) {
                    setPoint(position.coords.latitude, position.coords.longitude);
                    map.setView([position.coords.latitude, position.coords.longitude], 16);
                },
                function (error) {
                    console.error("Geolocation error:", error);
                    if (status) status.textContent = "Could not get your location. Click the map instead.";
                },
                { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
            );
        });
    }
});
