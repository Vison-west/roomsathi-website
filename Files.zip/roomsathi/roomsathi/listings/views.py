from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.core.paginator import Paginator
from django.db.models import Prefetch, Q
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.http import require_POST

from accounts.decorators import role_required
from accounts.models import LifestyleChoice, Role

from .forms import (
    ListingForm, MessageForm, RoomAlertForm, RoomSearchForm, RoommatePostForm, RoommateSearchForm,
)
from .models import (
    Conversation, GenderPreference, Listing, ListingImage, Message, RoomAlert, RoommatePost,
    SavedListing, Status,
)
from .services.alert_matching import send_alert_emails
from .services.roommate_matching import calculate_roommate_compatibility

host_only = role_required(Role.HOST)
seeker_only = role_required(Role.SEEKER)
admin_only = role_required(Role.ADMIN)



def _is_admin(user):
    return user.is_authenticated and user.role == Role.ADMIN


def _paginate(request, items):
    
    page_obj = Paginator(items, settings.PAGE_SIZE).get_page(request.GET.get("page"))
    params = request.GET.copy()
    params.pop("page", None)
    return page_obj, params.urlencode()


def _safe_next(request, fallback):
    target = request.POST.get("next", "")
    if target and url_has_allowed_host_and_scheme(
        target, allowed_hosts={request.get_host()}, require_https=request.is_secure()
    ):
        return target
    return fallback


def _seeker_lifestyle(user):
   
    if user.is_authenticated and user.role == Role.SEEKER:
        return user.lifestyle_set
    return None


def _label_map():
    return dict(LifestyleChoice.choices)


def _save_images(listing, files):
    has_primary = listing.images.filter(is_primary=True).exists()
    for f in files:
        ListingImage.objects.create(listing=listing, image=f, is_primary=not has_primary)
        has_primary = True



def find_rooms(request):
    form = RoomSearchForm(request.GET)
    cd = form.cleaned_data if form.is_valid() else {}
    qs = (Listing.objects.filter(status=Status.APPROVED)
          .select_related("host").prefetch_related("images", "amenities"))

    if cd.get("city"):
        qs = qs.filter(city__icontains=cd["city"])
    if cd.get("location"):
        qs = qs.filter(Q(address__icontains=cd["location"]) | Q(title__icontains=cd["location"]))
    if cd.get("room_type"):
        qs = qs.filter(room_type=cd["room_type"])
    if cd.get("min_rent") is not None:
        qs = qs.filter(rent__gte=cd["min_rent"])
    if cd.get("max_rent") is not None:
        qs = qs.filter(rent__lte=cd["max_rent"])
    if cd.get("gender"):
        qs = qs.filter(gender_preference__in=[GenderPreference.ANY, cd["gender"]])
    if cd.get("furnished") == "yes":
        qs = qs.filter(furnished=True)
    elif cd.get("furnished") == "no":
        qs = qs.filter(furnished=False)
    for amenity in cd.get("amenities", []):
        qs = qs.filter(amenities=amenity)  
    if cd.get("available_by"):
        qs = qs.filter(available_from__lte=cd["available_by"])

    qs = qs.order_by({"low": "rent", "high": "-rent"}.get(cd.get("sort"), "-created_at"))
    page_obj, querystring = _paginate(request, qs)
    return render(request, "listings/find_rooms.html",
                  {"form": form, "page_obj": page_obj, "querystring": querystring})


def room_detail(request, pk):
    listing = get_object_or_404(
        Listing.objects.select_related("host").prefetch_related("images", "amenities"), pk=pk)
    is_owner = request.user == listing.host
    if listing.status != Status.APPROVED and not (is_owner or _is_admin(request.user)):
        raise Http404
    is_saved = (
        request.user.is_authenticated and request.user.role == Role.SEEKER
        and SavedListing.objects.filter(user=request.user, listing=listing).exists()
    )
    return render(request, "listings/room_detail.html",
                  {"listing": listing, "is_owner": is_owner, "is_saved": is_saved})



def find_roommates(request):
    form = RoommateSearchForm(request.GET)
    cd = form.cleaned_data if form.is_valid() else {}
    qs = RoommatePost.objects.filter(status=Status.APPROVED).select_related("host")

    if cd.get("q"):
        qs = qs.filter(Q(title__icontains=cd["q"]) | Q(description__icontains=cd["q"])
                       | Q(address__icontains=cd["q"]))
    if cd.get("city"):
        qs = qs.filter(city__icontains=cd["city"])
    if cd.get("min_budget") is not None:
        qs = qs.filter(budget_share__gte=cd["min_budget"])
    if cd.get("max_budget") is not None:
        qs = qs.filter(budget_share__lte=cd["max_budget"])
    if cd.get("gender"):
        qs = qs.filter(preferred_gender__in=[GenderPreference.ANY, cd["gender"]])
    if cd.get("move_in_by"):
        qs = qs.filter(move_in_date__lte=cd["move_in_by"])

    posts = list(qs)  
    seeker_set = _seeker_lifestyle(request.user)
    show_compat = seeker_set is not None
    for post in posts:  
        post.compatibility = (
            calculate_roommate_compatibility(seeker_set, post.preferences_set) if show_compat else None
        )

    required = set(cd.get("lifestyle", []))
    if required:
        posts = [p for p in posts if required <= p.preferences_set]

    sort = cd.get("sort") or "newest"
    if sort == "low":
        posts.sort(key=lambda p: p.budget_share)
    elif sort == "high":
        posts.sort(key=lambda p: -p.budget_share)
    elif sort == "best" and show_compat:
       
        posts.sort(key=lambda p: (p.compatibility is None, -(p.compatibility or 0)))

    labels = _label_map()
    for post in posts:
        post.lifestyle_tags = [labels[v] for v in post.lifestyle_preferences if v in labels]

    page_obj, querystring = _paginate(request, posts)
    return render(request, "listings/find_roommates.html", {
        "form": form, "page_obj": page_obj, "querystring": querystring,
        "show_compat": show_compat,
        "best_match_note": sort == "best" and not show_compat,
    })


def roommate_detail(request, pk):
    post = get_object_or_404(RoommatePost.objects.select_related("host"), pk=pk)
    is_owner = request.user == post.host
    if post.status != Status.APPROVED and not (is_owner or _is_admin(request.user)):
        raise Http404
    seeker_set = _seeker_lifestyle(request.user)
    labels = _label_map()
    compat = calculate_roommate_compatibility(seeker_set, post.preferences_set) if seeker_set is not None else None
    common = sorted(seeker_set & post.preferences_set) if seeker_set is not None else []
    return render(request, "listings/roommate_detail.html", {
        "post": post, "is_owner": is_owner,
        "show_compat": seeker_set is not None, "compatibility": compat,
        "common_labels": [labels[v] for v in common if v in labels],
    })



@host_only
def my_listings(request):
    listings = (Listing.objects.filter(host=request.user)
                .prefetch_related("images").order_by("-created_at"))
    return render(request, "listings/my_listings.html", {"listings": listings})


@host_only
def listing_create(request):
    form = ListingForm(request.POST or None, request.FILES or None)
    if request.method == "POST" and form.is_valid():
        listing = form.save(commit=False)
        listing.host = request.user
        listing.status = Status.PENDING
        listing.save()
        form.save_m2m()
        _save_images(listing, form.cleaned_data["images"])
        messages.success(request, "Listing submitted. It will be public after admin approval.")
        return redirect("listings:my_listings")
    return render(request, "listings/listing_form.html", {"form": form, "mode": "create"})


@host_only
def listing_edit(request, pk):
    listing = get_object_or_404(Listing.objects.prefetch_related("images"), pk=pk, host=request.user)
    form = ListingForm(request.POST or None, request.FILES or None, instance=listing)
    if request.method == "POST" and form.is_valid():
        was_public = listing.status == Status.APPROVED
        listing = form.save(commit=False)
        listing.status = Status.PENDING  # every edit needs (re-)approval
        listing.rejection_reason = ""
        listing.save()
        form.save_m2m()
        _save_images(listing, form.cleaned_data["images"])
        messages.success(
            request,
            "Changes saved. The listing is hidden until an admin approves it again."
            if was_public else "Changes saved and sent for approval.",
        )
        return redirect("listings:my_listings")
    return render(request, "listings/listing_form.html",
                  {"form": form, "mode": "edit", "listing": listing, "images": listing.images.all()})


@host_only
@require_POST
def listing_image_delete(request, pk, image_id):
    image = get_object_or_404(ListingImage.objects.select_related("listing"),
                              pk=image_id, listing__pk=pk, listing__host=request.user)
    listing, was_primary = image.listing, image.is_primary
    image.image.delete(save=False)
    image.delete()
    if was_primary:
        first = listing.images.first()
        if first:
            first.is_primary = True
            first.save(update_fields=["is_primary"])
    messages.success(request, "Photo deleted.")
    return redirect("listings:listing_edit", pk=pk)


@host_only
@require_POST
def listing_image_primary(request, pk, image_id):
    image = get_object_or_404(ListingImage, pk=image_id, listing__pk=pk, listing__host=request.user)
    ListingImage.objects.filter(listing_id=pk).update(is_primary=False)
    image.is_primary = True
    image.save(update_fields=["is_primary"])
    messages.success(request, "Primary photo updated.")
    return redirect("listings:listing_edit", pk=pk)


def _delete_post(request, model, pk, redirect_name, label):
    obj = get_object_or_404(model, pk=pk, host=request.user)  # ownership enforced here
    if request.method == "POST":
        obj.delete()
        messages.success(request, f"{label} deleted.")
        return redirect(redirect_name)
    return render(request, "listings/confirm_delete.html",
                  {"object": obj, "label": label, "cancel_url": redirect_name})


def _toggle_hide(request, model, pk, redirect_name):
    obj = get_object_or_404(model, pk=pk, host=request.user)
    if obj.status == Status.INACTIVE:
        obj.status = Status.PENDING  # re-activating needs approval again
        messages.success(request, "Re-submitted for approval.")
    elif obj.status in (Status.APPROVED, Status.PENDING):
        obj.status = Status.INACTIVE
        messages.success(request, "Hidden from public view.")
    obj.save(update_fields=["status", "updated_at"])
    return redirect(redirect_name)


@host_only
def listing_delete(request, pk):
    return _delete_post(request, Listing, pk, "listings:my_listings", "Listing")


@host_only
@require_POST
def listing_hide(request, pk):
    return _toggle_hide(request, Listing, pk, "listings:my_listings")



@host_only
def my_roommate_posts(request):
    posts = RoommatePost.objects.filter(host=request.user).order_by("-created_at")
    return render(request, "listings/my_roommate_posts.html", {"posts": posts})


@host_only
def roommate_create(request):
    form = RoommatePostForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        post = form.save(commit=False)
        post.host = request.user
        post.status = Status.PENDING
        post.save()
        messages.success(request, "Roommate post submitted. It will be public after admin approval.")
        return redirect("listings:my_roommate_posts")
    return render(request, "listings/roommate_form.html", {"form": form, "mode": "create"})


@host_only
def roommate_edit(request, pk):
    post = get_object_or_404(RoommatePost, pk=pk, host=request.user)
    form = RoommatePostForm(request.POST or None, instance=post)
    if request.method == "POST" and form.is_valid():
        post = form.save(commit=False)
        post.status = Status.PENDING
        post.rejection_reason = ""
        post.save()
        messages.success(request, "Changes saved. The post needs admin approval again.")
        return redirect("listings:my_roommate_posts")
    return render(request, "listings/roommate_form.html", {"form": form, "mode": "edit", "post": post})


@host_only
def roommate_delete(request, pk):
    return _delete_post(request, RoommatePost, pk, "listings:my_roommate_posts", "Roommate post")


@host_only
@require_POST
def roommate_hide(request, pk):
    return _toggle_hide(request, RoommatePost, pk, "listings:my_roommate_posts")



@seeker_only
def saved_list(request):
    saved = (SavedListing.objects.filter(user=request.user, listing__status=Status.APPROVED)
             .select_related("listing__host").prefetch_related("listing__images", "listing__amenities"))
    page_obj, querystring = _paginate(request, saved)
    return render(request, "listings/saved_list.html", {"page_obj": page_obj, "querystring": querystring})


@seeker_only
@require_POST
def save_listing(request, pk):
    listing = get_object_or_404(Listing, pk=pk, status=Status.APPROVED)
    _, created = SavedListing.objects.get_or_create(user=request.user, listing=listing)  # no duplicates
    messages.success(request, "Listing saved." if created else "Already in your saved listings.")
    return redirect(_safe_next(request, "listings:saved_list"))


@seeker_only
@require_POST
def unsave_listing(request, pk):
    SavedListing.objects.filter(user=request.user, listing_id=pk).delete()
    messages.success(request, "Removed from saved listings.")
    return redirect(_safe_next(request, "listings:saved_list"))



@seeker_only
def alerts_list(request):
    return render(request, "listings/alerts_list.html",
                  {"alerts": RoomAlert.objects.filter(user=request.user)})


@seeker_only
def alert_create(request):
    form = RoomAlertForm(request.POST or None, initial={"is_active": True})
    if request.method == "POST" and form.is_valid():
        alert = form.save(commit=False)
        alert.user = request.user
        alert.save()
        messages.success(request, "Room alert created.")
        return redirect("listings:alerts_list")
    return render(request, "listings/alert_form.html", {"form": form, "mode": "create"})


@seeker_only
def alert_edit(request, pk):
    alert = get_object_or_404(RoomAlert, pk=pk, user=request.user)
    form = RoomAlertForm(request.POST or None, instance=alert)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Room alert updated.")
        return redirect("listings:alerts_list")
    return render(request, "listings/alert_form.html", {"form": form, "mode": "edit"})


@seeker_only
@require_POST
def alert_delete(request, pk):
    get_object_or_404(RoomAlert, pk=pk, user=request.user).delete()
    messages.success(request, "Room alert deleted.")
    return redirect("listings:alerts_list")


@seeker_only
@require_POST
def alert_toggle(request, pk):
    alert = get_object_or_404(RoomAlert, pk=pk, user=request.user)
    alert.is_active = not alert.is_active
    alert.save(update_fields=["is_active"])
    return redirect("listings:alerts_list")



@login_required
def inbox(request):
    user = request.user
    conversations = (
        Conversation.objects.filter(Q(seeker=user) | Q(host=user))
        .select_related("seeker", "host", "listing", "roommate_post")
        .prefetch_related(Prefetch("messages", queryset=Message.objects.order_by("-created_at"), to_attr="msgs"))
    )
    rows = []
    for convo in conversations:
        last = convo.msgs[0] if convo.msgs else None
        unread = sum(1 for m in convo.msgs if not m.is_read and m.sender_id != user.pk)
        rows.append({"convo": convo, "other": convo.other_user(user), "last": last, "unread": unread})
    return render(request, "listings/inbox.html", {"rows": rows})


@login_required
def conversation(request, pk):
    convo = get_object_or_404(
        Conversation.objects.select_related("seeker", "host", "listing", "roommate_post"), pk=pk)
    user = request.user
    if user.pk not in (convo.seeker_id, convo.host_id):
        raise PermissionDenied  

    form = MessageForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        Message.objects.create(conversation=convo, sender=user, body=form.cleaned_data["body"])
        convo.save(update_fields=["updated_at"])
        return redirect("listings:conversation", pk=pk)

    convo.messages.filter(is_read=False).exclude(sender=user).update(is_read=True)
    thread = convo.messages.select_related("sender")
    return render(request, "listings/conversation.html",
                  {"convo": convo, "thread": thread, "form": MessageForm(), "other": convo.other_user(user)})


@seeker_only
@require_POST
def message_room_host(request, pk):
    listing = get_object_or_404(Listing, pk=pk, status=Status.APPROVED)
    convo, _ = Conversation.objects.get_or_create(seeker=request.user, host=listing.host, listing=listing)
    return redirect("listings:conversation", pk=convo.pk)


@seeker_only
@require_POST
def message_roommate_host(request, pk):
    post = get_object_or_404(RoommatePost, pk=pk, status=Status.APPROVED)
    convo, _ = Conversation.objects.get_or_create(seeker=request.user, host=post.host, roommate_post=post)
    return redirect("listings:conversation", pk=convo.pk)



MODERATION_ACTIONS = {"approve", "reject", "hide", "delete"}


def _moderate(request, model, pk, action):
    if action not in MODERATION_ACTIONS:
        raise Http404
    obj = get_object_or_404(model, pk=pk)
    if action == "approve":
        obj.status = Status.APPROVED
        obj.rejection_reason = ""
        obj.save()
        if isinstance(obj, Listing) and not obj.alerts_sent:
            sent = send_alert_emails(obj)
            obj.alerts_sent = True
            obj.save(update_fields=["alerts_sent"])
            messages.success(request, f"Approved. {sent} alert email(s) sent.")
        else:
            messages.success(request, "Approved.")
    elif action == "reject":
        obj.status = Status.REJECTED
        obj.rejection_reason = request.POST.get("reason", "").strip()[:300]
        obj.save()
        messages.warning(request, "Rejected.")
    elif action == "hide":
        obj.status = Status.INACTIVE
        obj.save()
        messages.info(request, "Hidden from public view.")
    else:
        obj.delete()
        messages.info(request, "Deleted.")
    return redirect("core:admin_dashboard")


@admin_only
@require_POST
def admin_listing_action(request, pk, action):
    return _moderate(request, Listing, pk, action)


@admin_only
@require_POST
def admin_roommate_action(request, pk, action):
    return _moderate(request, RoommatePost, pk, action)
