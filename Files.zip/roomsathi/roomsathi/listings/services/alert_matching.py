"""Match a newly approved Listing against active RoomAlerts and email the seekers."""
from django.conf import settings
from django.core.mail import send_mail
from django.db.models import Q
from django.urls import reverse

from listings.models import GenderPreference, RoomAlert


def find_matching_alerts(listing):
    """Active alerts whose criteria all fit `listing` (blank criterion = don't care)."""
    alerts = RoomAlert.objects.filter(is_active=True).exclude(user=listing.host)
    alerts = alerts.filter(Q(city="") | Q(city__iexact=listing.city))
    alerts = alerts.filter(Q(room_type="") | Q(room_type=listing.room_type))
    alerts = alerts.filter(Q(max_rent__isnull=True) | Q(max_rent__gte=listing.rent))
    if listing.gender_preference != GenderPreference.ANY:
        alerts = alerts.filter(Q(gender_preference="") | Q(gender_preference=listing.gender_preference))
    return alerts.select_related("user")


def send_alert_emails(listing):
    """Email each matching seeker once. Returns the number of emails sent."""
    link = settings.SITE_URL.rstrip("/") + reverse("listings:room_detail", args=[listing.pk])
    short = (listing.description[:160] + "...") if len(listing.description) > 160 else listing.description
    recipients = {alert.user.email for alert in find_matching_alerts(listing) if alert.user.email}
    body = (
        f"A new room matching your alert is available on RoomSathi.\n\n"
        f"Title: {listing.title}\n"
        f"City: {listing.city}\n"
        f"Rent: NPR {listing.rent}/month\n"
        f"Room type: {listing.get_room_type_display()}\n\n"
        f"{short}\n\n"
        f"View it here: {link}\n"
    )
    for email in sorted(recipients):
        send_mail(f"New room in {listing.city}: {listing.title}", body, settings.DEFAULT_FROM_EMAIL,
                  [email], fail_silently=True)
    return len(recipients)
