


def calculate_jaccard_similarity(set_a, set_b):
    
    a, b = set(set_a or ()), set(set_b or ())
    union = a | b
    if not union:
        return None
    return len(a & b) / len(union)


def calculate_roommate_compatibility(seeker_preferences, host_preferences):
    
    seeker, host = set(seeker_preferences or ()), set(host_preferences or ())
    if not seeker or not host:
        return None
    return round(calculate_jaccard_similarity(seeker, host) * 100, 2)


def format_compatibility(percentage):
    
    if percentage is None:
        return "Not enough data"
    return f"{percentage:g}% Lifestyle Compatibility"
