from .models import unread_count


def unread_messages(request):
    user = request.user
    if user.is_authenticated and user.role in ("SEEKER", "HOST"):
        return {"unread_count": unread_count(user)}
    return {}
