from django.contrib import admin

from .models import (
    Amenity, Conversation, Listing, ListingImage, Message, RoomAlert, RoommatePost, SavedListing,
)


class ListingImageInline(admin.TabularInline):
    model = ListingImage
    extra = 0


@admin.register(Listing)
class ListingAdmin(admin.ModelAdmin):
    list_display = ("title", "host", "city", "rent", "room_type", "status", "created_at")
    list_filter = ("status", "room_type", "city")
    search_fields = ("title", "city", "address", "host__email")
    inlines = [ListingImageInline]
    actions = ["approve_selected", "reject_selected"]

    @admin.action(description="Approve selected listings")
    def approve_selected(self, request, queryset):
        queryset.update(status="APPROVED")

    @admin.action(description="Reject selected listings")
    def reject_selected(self, request, queryset):
        queryset.update(status="REJECTED")


@admin.register(RoommatePost)
class RoommatePostAdmin(admin.ModelAdmin):
    list_display = ("title", "host", "city", "budget_share", "status", "created_at")
    list_filter = ("status", "city")
    search_fields = ("title", "city", "host__email")


admin.site.register([Amenity, SavedListing, RoomAlert, Conversation, Message])
