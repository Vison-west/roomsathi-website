from django.apps import AppConfig
from django.db.models.signals import post_migrate


def create_default_amenities(sender, **kwargs):
    from .models import DEFAULT_AMENITIES, Amenity

    for name in DEFAULT_AMENITIES:
        Amenity.objects.get_or_create(name=name)


class ListingsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "listings"

    def ready(self):
        post_migrate.connect(create_default_amenities, sender=self)
