"""Create demo accounts and sample data so the app is usable immediately.

    python manage.py seed_demo

Safe to run many times (it skips anything that already exists).
"""
from datetime import date, timedelta
from decimal import Decimal

from django.core.management.base import BaseCommand

from accounts.models import Role, User
from listings.models import Amenity, Listing, RoomAlert, RoommatePost, Status

DEMO_PASSWORDS = {
    "admin@roomsathi.com": "Admin@12345",
    "host@roomsathi.com": "Host@12345",
    "host2@roomsathi.com": "Host@12345",
    "seeker@roomsathi.com": "Seeker@12345",
    "seeker2@roomsathi.com": "Seeker@12345",
}

CITIES = {
    "Butwal": (Decimal("27.700600"), Decimal("83.448400")),
    "Pokhara": (Decimal("28.209600"), Decimal("83.985600")),
    "Kathmandu": (Decimal("27.717200"), Decimal("85.324000")),
}


class Command(BaseCommand):
    help = "Create demo users, listings, roommate posts and an alert."

    def handle(self, *args, **options):
        admin = self._user("admin@roomsathi.com", "Admin User", Role.ADMIN, superuser=True)
        host1 = self._user("host@roomsathi.com", "Ram Thapa", Role.HOST, phone="9800000001", city="Butwal", gender="M")
        host2 = self._user("host2@roomsathi.com", "Sita Gurung", Role.HOST, phone="9800000002", city="Pokhara", gender="F")
        self._user("seeker@roomsathi.com", "Hari Sharma", Role.SEEKER, phone="9800000003", city="Butwal",
                   gender="M", college="Butwal Multiple Campus",
                   lifestyle=["early_bird", "very_clean", "quiet", "non_smoker"])
        self._user("seeker2@roomsathi.com", "Maya Rai", Role.SEEKER, phone="9800000004", city="Pokhara",
                   gender="F", college="Prithvi Narayan Campus",
                   lifestyle=["night_owl", "social", "non_smoker", "vegetarian"])

        amenities = list(Amenity.objects.all())
        room_types = ["SINGLE", "SHARED", "1BHK", "2BHK", "FLAT", "APARTMENT"]
        today = date.today()
        made = 0
        for i in range(12):
            city = list(CITIES)[i % 3]
            lat, lng = CITIES[city]
            title = f"{room_types[i % 6].title()} near campus, {city} #{i + 1}"
            if Listing.objects.filter(title=title).exists():
                continue
            listing = Listing.objects.create(
                title=title, host=host1 if i % 2 == 0 else host2,
                description="Clean and well-lit place close to colleges, markets and public transport. "
                            "Suitable for students. Water and electricity available 24/7.",
                city=city, address=f"Ward {i % 9 + 1}, near main road",
                latitude=lat + Decimal(i) / Decimal(1000), longitude=lng + Decimal(i) / Decimal(1000),
                room_type=room_types[i % 6], rent=5000 + i * 700, deposit=5000,
                gender_preference=["ANY", "M", "F"][i % 3],
                available_from=today + timedelta(days=7 + i), furnished=i % 2 == 0,
                status=Status.APPROVED, alerts_sent=True,
            )
            listing.amenities.set(amenities[i % 3: i % 3 + 4])
            made += 1
        Listing.objects.get_or_create(
            title="Pending demo room (waiting for admin)", host=host1,
            defaults=dict(description="Approve me from the admin dashboard.", city="Butwal", address="Traffic Chowk",
                          room_type="SINGLE", rent=7500, available_from=today + timedelta(days=3),
                          status=Status.PENDING),
        )

        posts = [
            ("Quiet roommate wanted in 2BHK, Butwal", "Butwal", 8000, "M", ["very_clean", "quiet", "non_smoker", "early_bird"]),
            ("Vacant space in student flat, Butwal", "Butwal", 6500, "ANY", ["very_clean", "quiet", "vegetarian"]),
            ("Social roommate for Pokhara flat", "Pokhara", 9000, "F", ["social", "night_owl", "pet_friendly"]),
            ("Study-focused roommate, Kathmandu", "Kathmandu", 11000, "ANY", ["study_focused", "quiet", "non_smoker"]),
            ("Relaxed flatmate wanted, Pokhara", "Pokhara", 7000, "ANY", ["relaxed_clean", "social", "non_vegetarian"]),
            ("Early bird roommate, Butwal", "Butwal", 7200, "M", ["early_bird", "non_smoker", "very_clean"]),
        ]
        for i, (title, city, budget, gender, prefs) in enumerate(posts):
            lat, lng = CITIES[city]
            RoommatePost.objects.get_or_create(
                title=title, host=host1 if city == "Butwal" else host2,
                defaults=dict(
                    description="I have one vacant space in my flat and want a compatible roommate. "
                                "Please read the lifestyle requirements below.",
                    city=city, address=f"Ward {i + 2}", latitude=lat + Decimal(i) / Decimal(500),
                    longitude=lng + Decimal(i) / Decimal(500), budget_share=budget, preferred_gender=gender,
                    move_in_date=today + timedelta(days=10 + i * 3), lifestyle_preferences=prefs,
                    status=Status.APPROVED,
                ),
            )
        seeker = User.objects.get(email="seeker@roomsathi.com")
        RoomAlert.objects.get_or_create(user=seeker, city="Butwal", max_rent=10000, defaults={"room_type": "SINGLE"})

        self.stdout.write(self.style.SUCCESS(f"Demo data ready ({made} new listings)."))
        self.stdout.write("Demo logins (email / password):")
        for email, pw in DEMO_PASSWORDS.items():
            self.stdout.write(f"  {email}  /  {pw}")

    def _user(self, email, name, role, superuser=False, **extra):
        user = User.objects.filter(email=email).first()
        if user:
            return user
        password = DEMO_PASSWORDS[email]
        if superuser:
            return User.objects.create_superuser(email, password, name=name, **extra)
        return User.objects.create_user(email, password, name=name, role=role, **extra)
