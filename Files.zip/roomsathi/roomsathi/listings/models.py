from django.conf import settings
from django.core.validators import MinValueValidator
from django.db import models
from django.db.models import Q

from accounts.models import LifestyleChoice
from accounts.validators import validate_image_file

User = settings.AUTH_USER_MODEL


class Status(models.TextChoices):
    PENDING = "PENDING", "Pending"
    APPROVED = "APPROVED", "Approved"
    REJECTED = "REJECTED", "Rejected"
    INACTIVE = "INACTIVE", "Hidden"


class RoomType(models.TextChoices):
    SINGLE = "SINGLE", "Single Room"
    SHARED = "SHARED", "Shared Room"
    BHK1 = "1BHK", "1BHK"
    BHK2 = "2BHK", "2BHK"
    BHK3 = "3BHK", "3BHK"
    FLAT = "FLAT", "Flat"
    APARTMENT = "APARTMENT", "Apartment"
    OTHER = "OTHER", "Other"


class GenderPreference(models.TextChoices):
    ANY = "ANY", "Any"
    MALE = "M", "Male only"
    FEMALE = "F", "Female only"


DEFAULT_AMENITIES = [
    "WiFi", "Attached Bathroom", "Running Water", "Hot Water", "Parking",
    "Kitchen", "Laundry", "Balcony", "Electricity Backup", "Study Table",
]


class Amenity(models.Model):
    name = models.CharField(max_length=50, unique=True)

    class Meta:
        ordering = ["name"]
        verbose_name_plural = "amenities"

    def __str__(self):
        return self.name


class Listing(models.Model):
    

    title = models.CharField(max_length=150)
    description = models.TextField()
    host = models.ForeignKey(User, on_delete=models.CASCADE, related_name="listings")
    city = models.CharField(max_length=80)
    address = models.CharField(max_length=200)
    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    room_type = models.CharField(max_length=12, choices=RoomType.choices, default=RoomType.SINGLE)
    rent = models.PositiveIntegerField(validators=[MinValueValidator(1)], help_text="NPR per month")
    deposit = models.PositiveIntegerField(default=0, help_text="NPR")
    gender_preference = models.CharField(max_length=3, choices=GenderPreference.choices, default=GenderPreference.ANY)
    available_from = models.DateField()
    amenities = models.ManyToManyField(Amenity, blank=True, related_name="listings")
    furnished = models.BooleanField(default=False)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING, db_index=True)
    rejection_reason = models.CharField(max_length=300, blank=True)
    alerts_sent = models.BooleanField(default=False)  # email alerts go out only once
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.title

    @property
    def cover_image(self):
        images = list(self.images.all())  
        for img in images:
            if img.is_primary:
                return img
        return images[0] if images else None


class ListingImage(models.Model):
    listing = models.ForeignKey(Listing, on_delete=models.CASCADE, related_name="images")
    image = models.ImageField(upload_to="listing_images/", validators=[validate_image_file])
    is_primary = models.BooleanField(default=False)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-is_primary", "uploaded_at"]

    def __str__(self):
        return f"Image {self.pk} of listing {self.listing_id}"


class RoommatePost(models.Model):
    

    title = models.CharField(max_length=150)
    description = models.TextField()
    host = models.ForeignKey(User, on_delete=models.CASCADE, related_name="roommate_posts")
    city = models.CharField(max_length=80)
    address = models.CharField(max_length=200)
    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    budget_share = models.PositiveIntegerField(validators=[MinValueValidator(1)], help_text="NPR per month")
    preferred_gender = models.CharField(max_length=3, choices=GenderPreference.choices, default=GenderPreference.ANY)
    move_in_date = models.DateField()
    
    lifestyle_preferences = models.JSONField(default=list, blank=True)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING, db_index=True)
    rejection_reason = models.CharField(max_length=300, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.title

    @property
    def preferences_set(self):
        return set(self.lifestyle_preferences or [])

    def preference_labels(self):
        labels = dict(LifestyleChoice.choices)
        return [labels[v] for v in (self.lifestyle_preferences or []) if v in labels]


class SavedListing(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="saved_listings")
    listing = models.ForeignKey(Listing, on_delete=models.CASCADE, related_name="saved_by")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        constraints = [models.UniqueConstraint(fields=["user", "listing"], name="unique_saved_listing")]

    def __str__(self):
        return f"{self.user_id} saved {self.listing_id}"


class RoomAlert(models.Model):
    ANY_GENDER_CHOICES = [("", "Any"), ("M", "Male"), ("F", "Female")]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="room_alerts")
    city = models.CharField(max_length=80, blank=True)
    room_type = models.CharField(max_length=12, choices=RoomType.choices, blank=True)
    max_rent = models.PositiveIntegerField(null=True, blank=True, help_text="NPR per month")
    gender_preference = models.CharField(max_length=1, choices=ANY_GENDER_CHOICES, blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"Alert #{self.pk} ({self.city or 'any city'})"


class Conversation(models.Model):
    seeker = models.ForeignKey(User, on_delete=models.CASCADE, related_name="seeker_conversations")
    host = models.ForeignKey(User, on_delete=models.CASCADE, related_name="host_conversations")
    listing = models.ForeignKey(Listing, on_delete=models.CASCADE, null=True, blank=True, related_name="conversations")
    roommate_post = models.ForeignKey(
        RoommatePost, on_delete=models.CASCADE, null=True, blank=True, related_name="conversations"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-updated_at"]

    @property
    def subject(self):
        if self.listing_id:
            return self.listing.title
        if self.roommate_post_id:
            return self.roommate_post.title
        return "Conversation"

    def other_user(self, user):
        return self.host if user.pk == self.seeker_id else self.seeker

    def __str__(self):
        return f"Conversation {self.pk}"


class Message(models.Model):
    conversation = models.ForeignKey(Conversation, on_delete=models.CASCADE, related_name="messages")
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name="sent_messages")
    body = models.TextField(max_length=2000)
    created_at = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)

    class Meta:
        ordering = ["created_at"]

    def __str__(self):
        return f"Message {self.pk}"


def unread_count(user):
    
    return (
        Message.objects.filter(is_read=False)
        .filter(Q(conversation__seeker=user) | Q(conversation__host=user))
        .exclude(sender=user)
        .count()
    )
