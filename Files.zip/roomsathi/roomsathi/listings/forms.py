from django import forms

from accounts.forms import BootstrapFormMixin
from accounts.models import LifestyleChoice
from accounts.validators import validate_image_file

from .models import Amenity, GenderPreference, Listing, RoomAlert, RoommatePost, RoomType

MAX_IMAGES = 8
GENDER_FILTER_CHOICES = [("", "Any"), ("M", "Male"), ("F", "Female")]
DATE_WIDGET = forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d")


class MultipleFileInput(forms.ClearableFileInput):
    allow_multiple_selected = True


class MultipleFileField(forms.FileField):
    def __init__(self, *args, **kwargs):
        kwargs.setdefault("widget", MultipleFileInput(attrs={"multiple": True, "accept": "image/*"}))
        super().__init__(*args, **kwargs)

    def clean(self, data, initial=None):
        clean_one = super().clean
        if isinstance(data, (list, tuple)):
            return [clean_one(d, initial) for d in data if d]
        return [clean_one(data, initial)] if data else []


class LocationMixin:
   

    def clean(self):
        cleaned = super().clean()
        lat, lng = cleaned.get("latitude"), cleaned.get("longitude")
        if (lat is None) != (lng is None):
            raise forms.ValidationError("Choose a point on the map (both latitude and longitude are needed).")
        if lat is not None and not (-90 <= lat <= 90 and -180 <= lng <= 180):
            raise forms.ValidationError("Location is outside the valid latitude/longitude range.")
        return cleaned


class ListingForm(LocationMixin, BootstrapFormMixin, forms.ModelForm):
    amenities = forms.ModelMultipleChoiceField(
        queryset=Amenity.objects.all(), widget=forms.CheckboxSelectMultiple, required=False
    )
    images = MultipleFileField(required=False, label=f"Photos (up to {MAX_IMAGES}, JPG/PNG/WEBP, max 2 MB each)")

    class Meta:
        model = Listing
        fields = ["title", "description", "city", "address", "room_type", "rent", "deposit",
                  "gender_preference", "available_from", "furnished", "amenities", "latitude", "longitude"]
        widgets = {
            "description": forms.Textarea(attrs={"rows": 4}),
            "available_from": DATE_WIDGET,
            "latitude": forms.HiddenInput(),
            "longitude": forms.HiddenInput(),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["available_from"].widget.format = "%Y-%m-%d"

    def clean_images(self):
        files = self.cleaned_data.get("images") or []
        existing = self.instance.images.count() if self.instance.pk else 0
        if len(files) + existing > MAX_IMAGES:
            raise forms.ValidationError(f"A listing can have at most {MAX_IMAGES} photos.")
        for f in files:
            validate_image_file(f)
        return files


class RoommatePostForm(LocationMixin, BootstrapFormMixin, forms.ModelForm):
    lifestyle_preferences = forms.MultipleChoiceField(
        choices=LifestyleChoice.choices,
        widget=forms.CheckboxSelectMultiple,
        required=False,
        label="Looking for (roommate lifestyle)",
    )

    class Meta:
        model = RoommatePost
        fields = ["title", "description", "city", "address", "budget_share", "preferred_gender",
                  "move_in_date", "lifestyle_preferences", "latitude", "longitude"]
        widgets = {
            "description": forms.Textarea(attrs={"rows": 4}),
            "move_in_date": DATE_WIDGET,
            "latitude": forms.HiddenInput(),
            "longitude": forms.HiddenInput(),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["move_in_date"].widget.format = "%Y-%m-%d"


class RoomSearchForm(BootstrapFormMixin, forms.Form):
    

    SORT_CHOICES = [("newest", "Newest"), ("low", "Lowest rent"), ("high", "Highest rent")]

    city = forms.CharField(required=False)
    location = forms.CharField(required=False, label="Area / address")
    room_type = forms.ChoiceField(required=False, choices=[("", "Any")] + RoomType.choices)
    min_rent = forms.IntegerField(required=False, min_value=0, label="Min rent (NPR)")
    max_rent = forms.IntegerField(required=False, min_value=0, label="Max rent (NPR)")
    gender = forms.ChoiceField(required=False, choices=GENDER_FILTER_CHOICES)
    furnished = forms.ChoiceField(
        required=False, choices=[("", "Any"), ("yes", "Furnished"), ("no", "Unfurnished")]
    )
    amenities = forms.ModelMultipleChoiceField(
        queryset=Amenity.objects.all(), widget=forms.CheckboxSelectMultiple, required=False
    )
    available_by = forms.DateField(required=False, widget=DATE_WIDGET, label="Available by")
    sort = forms.ChoiceField(required=False, choices=SORT_CHOICES)


class RoommateSearchForm(BootstrapFormMixin, forms.Form):
    

    SORT_CHOICES = [("newest", "Newest"), ("low", "Lowest Budget"), ("high", "Highest Budget"),
                    ("best", "Best Match")]

    q = forms.CharField(required=False, label="Keyword")
    city = forms.CharField(required=False)
    min_budget = forms.IntegerField(required=False, min_value=0, label="Min budget (NPR)")
    max_budget = forms.IntegerField(required=False, min_value=0, label="Max budget (NPR)")
    gender = forms.ChoiceField(required=False, choices=GENDER_FILTER_CHOICES)
    move_in_by = forms.DateField(required=False, widget=DATE_WIDGET, label="Move-in on or before")
    lifestyle = forms.MultipleChoiceField(
        required=False, choices=LifestyleChoice.choices, widget=forms.CheckboxSelectMultiple,
        label="Must include lifestyle",
    )
    sort = forms.ChoiceField(required=False, choices=SORT_CHOICES)


class RoomAlertForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = RoomAlert
        fields = ["city", "room_type", "max_rent", "gender_preference", "is_active"]
        labels = {"max_rent": "Maximum rent (NPR)", "is_active": "Alert is active"}


class MessageForm(BootstrapFormMixin, forms.Form):
    body = forms.CharField(
        max_length=2000, widget=forms.Textarea(attrs={"rows": 2, "placeholder": "Write a message..."}), label=""
    )

    def clean_body(self):
        body = self.cleaned_data["body"].strip()
        if not body:
            raise forms.ValidationError("Message cannot be empty.")
        return body
