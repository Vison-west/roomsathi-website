import io
import shutil
import tempfile
from datetime import date

from django.core import mail
from django.core.files.uploadedfile import SimpleUploadedFile
from django.db import IntegrityError, transaction
from django.test import SimpleTestCase, TestCase, override_settings
from django.urls import reverse

from accounts.models import Role, User
from listings.models import (
    Conversation, Listing, ListingImage, Message, RoomAlert, RoommatePost, SavedListing, Status, unread_count,
)
from listings.services.alert_matching import find_matching_alerts
from listings.services.roommate_matching import (
    calculate_jaccard_similarity, calculate_roommate_compatibility, format_compatibility,
)

PW = "Sathi#Pass2026x"


def make_user(email, role, **kw):
    return User.objects.create_user(email, PW, name=email.split("@")[0], role=role, **kw)


def make_listing(host, **over):
    data = dict(title="Nice room", description="Clean room near campus", city="Butwal", address="Ward 3",
                room_type="SINGLE", rent=8000, deposit=0, gender_preference="ANY",
                available_from=date(2026, 11, 1), status=Status.APPROVED)
    data.update(over)
    return Listing.objects.create(host=host, **data)


def make_post(host, **over):
    data = dict(title="Roommate wanted", description="Vacant space", city="Butwal", address="Ward 2",
                budget_share=7000, preferred_gender="ANY", move_in_date=date(2026, 11, 1),
                lifestyle_preferences=["very_clean", "quiet"], status=Status.APPROVED)
    data.update(over)
    return RoommatePost.objects.create(host=host, **data)


def listing_form_data(**over):
    data = {"title": "My room", "description": "Spacious", "city": "Butwal", "address": "Ward 5",
            "room_type": "SINGLE", "rent": 9000, "deposit": 3000, "gender_preference": "ANY",
            "available_from": "2026-11-15"}
    data.update(over)
    return data


def post_form_data(**over):
    data = {"title": "Need a roommate", "description": "One vacant bed", "city": "Butwal", "address": "Ward 6",
            "budget_share": 6000, "preferred_gender": "ANY", "move_in_date": "2026-11-20",
            "lifestyle_preferences": ["quiet", "very_clean"]}
    data.update(over)
    return data


def image_file(name="photo.png"):
    from PIL import Image
    buf = io.BytesIO()
    Image.new("RGB", (20, 20), "red").save(buf, "PNG")
    return SimpleUploadedFile(name, buf.getvalue(), content_type="image/png")


# ------------------------------------------------------------------ Jaccard
class JaccardTests(SimpleTestCase):
    def test_identical_sets(self):
        self.assertEqual(calculate_roommate_compatibility({"clean", "quiet"}, {"clean", "quiet"}), 100.0)

    def test_partial_overlap(self):
        self.assertEqual(calculate_roommate_compatibility({"clean", "quiet"}, {"clean", "social"}), 33.33)

    def test_spec_example_is_sixty_percent(self):
        seeker = {"clean", "quiet", "early_bird", "non_smoker"}
        host = {"clean", "quiet", "early_bird", "vegetarian"}
        self.assertEqual(calculate_roommate_compatibility(seeker, host), 60.0)

    def test_no_overlap(self):
        self.assertEqual(calculate_roommate_compatibility({"quiet"}, {"social"}), 0.0)

    def test_empty_sets_give_not_enough_data(self):
        self.assertIsNone(calculate_jaccard_similarity(set(), set()))
        self.assertIsNone(calculate_roommate_compatibility(set(), {"quiet"}))
        self.assertIsNone(calculate_roommate_compatibility({"quiet"}, set()))
        self.assertEqual(format_compatibility(None), "Not enough data")

    def test_accepts_lists_and_none(self):
        self.assertEqual(calculate_roommate_compatibility(["a", "b"], ["a", "b"]), 100.0)
        self.assertIsNone(calculate_roommate_compatibility(None, None))


# ------------------------------------------------------------------ Room listings
class RoomListingTests(TestCase):
    def setUp(self):
        self.host = make_user("host@example.com", Role.HOST)
        self.other_host = make_user("host2@example.com", Role.HOST)
        self.seeker = make_user("seeker@example.com", Role.SEEKER)
        self.admin = User.objects.create_superuser("admin@example.com", PW, name="Admin")

    def test_host_creates_listing_as_pending(self):
        self.client.force_login(self.host)
        resp = self.client.post(reverse("listings:listing_create"), listing_form_data())
        self.assertRedirects(resp, reverse("listings:my_listings"))
        listing = Listing.objects.get(title="My room")
        self.assertEqual(listing.status, Status.PENDING)
        self.assertEqual(listing.host, self.host)

    def test_seeker_cannot_create_listing(self):
        self.client.force_login(self.seeker)
        self.assertEqual(self.client.get(reverse("listings:listing_create")).status_code, 403)

    def test_anonymous_redirected_from_create(self):
        resp = self.client.get(reverse("listings:listing_create"))
        self.assertEqual(resp.status_code, 302)

    def test_pending_listing_not_public(self):
        listing = make_listing(self.host, status=Status.PENDING)
        resp = self.client.get(reverse("listings:find_rooms"))
        self.assertNotContains(resp, listing.title)
        self.assertEqual(self.client.get(reverse("listings:room_detail", args=[listing.pk])).status_code, 404)

    def test_approved_listing_is_public(self):
        listing = make_listing(self.host, title="Public room")
        self.assertContains(self.client.get(reverse("listings:find_rooms")), "Public room")
        self.assertEqual(self.client.get(reverse("listings:room_detail", args=[listing.pk])).status_code, 200)

    def test_owner_can_view_own_pending_listing(self):
        listing = make_listing(self.host, status=Status.PENDING)
        self.client.force_login(self.host)
        self.assertEqual(self.client.get(reverse("listings:room_detail", args=[listing.pk])).status_code, 200)

    def test_editing_approved_listing_resets_to_pending(self):
        listing = make_listing(self.host)
        self.client.force_login(self.host)
        self.client.post(reverse("listings:listing_edit", args=[listing.pk]), listing_form_data(title="Changed"))
        listing.refresh_from_db()
        self.assertEqual(listing.title, "Changed")
        self.assertEqual(listing.status, Status.PENDING)
        self.assertNotContains(self.client.get(reverse("listings:find_rooms")), "Changed")

    def test_other_host_cannot_edit_or_delete(self):
        listing = make_listing(self.host)
        self.client.force_login(self.other_host)
        self.assertEqual(self.client.get(reverse("listings:listing_edit", args=[listing.pk])).status_code, 404)
        self.assertEqual(self.client.post(reverse("listings:listing_delete", args=[listing.pk])).status_code, 404)
        self.assertTrue(Listing.objects.filter(pk=listing.pk).exists())

    def test_host_can_delete_own_listing(self):
        listing = make_listing(self.host)
        self.client.force_login(self.host)
        self.client.post(reverse("listings:listing_delete", args=[listing.pk]))
        self.assertFalse(Listing.objects.filter(pk=listing.pk).exists())

    def test_host_can_hide_and_reactivate(self):
        listing = make_listing(self.host)
        self.client.force_login(self.host)
        self.client.post(reverse("listings:listing_hide", args=[listing.pk]))
        listing.refresh_from_db()
        self.assertEqual(listing.status, Status.INACTIVE)
        self.client.post(reverse("listings:listing_hide", args=[listing.pk]))
        listing.refresh_from_db()
        self.assertEqual(listing.status, Status.PENDING)

    def test_admin_approves_listing(self):
        listing = make_listing(self.host, status=Status.PENDING)
        self.client.force_login(self.admin)
        self.client.post(reverse("listings:admin_listing_action", args=[listing.pk, "approve"]))
        listing.refresh_from_db()
        self.assertEqual(listing.status, Status.APPROVED)

    def test_admin_rejects_listing_with_reason(self):
        listing = make_listing(self.host, status=Status.PENDING)
        self.client.force_login(self.admin)
        self.client.post(reverse("listings:admin_listing_action", args=[listing.pk, "reject"]),
                         {"reason": "Blurry photos"})
        listing.refresh_from_db()
        self.assertEqual(listing.status, Status.REJECTED)
        self.assertEqual(listing.rejection_reason, "Blurry photos")
        self.assertNotContains(self.client.get(reverse("listings:find_rooms")), listing.title)

    def test_admin_can_hide_and_delete(self):
        listing = make_listing(self.host)
        self.client.force_login(self.admin)
        self.client.post(reverse("listings:admin_listing_action", args=[listing.pk, "hide"]))
        listing.refresh_from_db()
        self.assertEqual(listing.status, Status.INACTIVE)
        self.client.post(reverse("listings:admin_listing_action", args=[listing.pk, "delete"]))
        self.assertFalse(Listing.objects.filter(pk=listing.pk).exists())

    def test_non_admin_cannot_moderate(self):
        listing = make_listing(self.host, status=Status.PENDING)
        for user in (self.host, self.seeker):
            self.client.force_login(user)
            resp = self.client.post(reverse("listings:admin_listing_action", args=[listing.pk, "approve"]))
            self.assertEqual(resp.status_code, 403)
        listing.refresh_from_db()
        self.assertEqual(listing.status, Status.PENDING)

    def test_find_rooms_filters(self):
        make_listing(self.host, title="Cheap Butwal", rent=5000)
        make_listing(self.host, title="Pricey Butwal", rent=20000)
        make_listing(self.host, title="Pokhara room", city="Pokhara", rent=6000)
        resp = self.client.get(reverse("listings:find_rooms"), {"city": "Butwal", "max_rent": 10000})
        self.assertContains(resp, "Cheap Butwal")
        self.assertNotContains(resp, "Pricey Butwal")
        self.assertNotContains(resp, "Pokhara room")

    def test_gender_filter(self):
        make_listing(self.host, title="Females only", gender_preference="F")
        make_listing(self.host, title="Open to all", gender_preference="ANY")
        resp = self.client.get(reverse("listings:find_rooms"), {"gender": "M"})
        self.assertContains(resp, "Open to all")
        self.assertNotContains(resp, "Females only")

    def test_pagination_nine_per_page(self):
        for i in range(12):
            make_listing(self.host, title=f"Room number {i}")
        page1 = self.client.get(reverse("listings:find_rooms"))
        page2 = self.client.get(reverse("listings:find_rooms"), {"page": 2})
        self.assertEqual(len(page1.context["page_obj"]), 9)
        self.assertEqual(len(page2.context["page_obj"]), 3)

    def test_invalid_location_pair_rejected(self):
        self.client.force_login(self.host)
        resp = self.client.post(reverse("listings:listing_create"), listing_form_data(latitude="27.7"))
        self.assertEqual(resp.status_code, 200)
        self.assertFalse(Listing.objects.exists())

    def test_location_saved(self):
        self.client.force_login(self.host)
        self.client.post(reverse("listings:listing_create"),
                         listing_form_data(latitude="27.700600", longitude="83.448400"))
        listing = Listing.objects.get()
        self.assertEqual(float(listing.latitude), 27.7006)


class ListingImageTests(TestCase):
    def setUp(self):
        self.media = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, self.media, ignore_errors=True)
        self.host = make_user("host@example.com", Role.HOST)
        self.client.force_login(self.host)

    def test_upload_primary_and_delete(self):
        with override_settings(MEDIA_ROOT=self.media):
            data = listing_form_data()
            data["images"] = [image_file("a.png"), image_file("b.png")]
            self.client.post(reverse("listings:listing_create"), data)
            listing = Listing.objects.get()
            self.assertEqual(listing.images.count(), 2)
            self.assertEqual(listing.images.filter(is_primary=True).count(), 1)
            second = listing.images.filter(is_primary=False).get()
            self.client.post(reverse("listings:listing_image_primary", args=[listing.pk, second.pk]))
            second.refresh_from_db()
            self.assertTrue(second.is_primary)
            self.assertEqual(listing.images.filter(is_primary=True).count(), 1)
            self.client.post(reverse("listings:listing_image_delete", args=[listing.pk, second.pk]))
            self.assertEqual(listing.images.count(), 1)
            self.assertTrue(listing.images.get().is_primary)

    def test_rejects_non_image(self):
        with override_settings(MEDIA_ROOT=self.media):
            data = listing_form_data()
            data["images"] = [SimpleUploadedFile("evil.txt", b"not an image", content_type="text/plain")]
            resp = self.client.post(reverse("listings:listing_create"), data)
            self.assertEqual(resp.status_code, 200)
            self.assertFalse(Listing.objects.exists())

    def test_other_host_cannot_delete_image(self):
        with override_settings(MEDIA_ROOT=self.media):
            data = listing_form_data()
            data["images"] = [image_file()]
            self.client.post(reverse("listings:listing_create"), data)
            listing = Listing.objects.get()
            image = listing.images.get()
            intruder = make_user("intruder@example.com", Role.HOST)
            self.client.force_login(intruder)
            resp = self.client.post(reverse("listings:listing_image_delete", args=[listing.pk, image.pk]))
            self.assertEqual(resp.status_code, 404)
            self.assertTrue(ListingImage.objects.filter(pk=image.pk).exists())


# ------------------------------------------------------------------ Roommate posts
class RoommatePostTests(TestCase):
    def setUp(self):
        self.host = make_user("host@example.com", Role.HOST)
        self.other_host = make_user("host2@example.com", Role.HOST)
        self.seeker = make_user("seeker@example.com", Role.SEEKER,
                                lifestyle=["very_clean", "quiet", "early_bird", "non_smoker"])
        self.admin = User.objects.create_superuser("admin@example.com", PW, name="Admin")

    def test_host_creates_post_pending(self):
        self.client.force_login(self.host)
        self.client.post(reverse("listings:roommate_create"), post_form_data())
        post = RoommatePost.objects.get()
        self.assertEqual(post.status, Status.PENDING)
        self.assertEqual(set(post.lifestyle_preferences), {"quiet", "very_clean"})

    def test_seeker_cannot_create_post(self):
        self.client.force_login(self.seeker)
        self.assertEqual(self.client.get(reverse("listings:roommate_create")).status_code, 403)

    def test_edit_resets_to_pending(self):
        post = make_post(self.host)
        self.client.force_login(self.host)
        self.client.post(reverse("listings:roommate_edit", args=[post.pk]), post_form_data(title="Updated"))
        post.refresh_from_db()
        self.assertEqual(post.status, Status.PENDING)
        self.assertEqual(post.title, "Updated")

    def test_ownership_on_edit_and_delete(self):
        post = make_post(self.host)
        self.client.force_login(self.other_host)
        self.assertEqual(self.client.get(reverse("listings:roommate_edit", args=[post.pk])).status_code, 404)
        self.assertEqual(self.client.post(reverse("listings:roommate_delete", args=[post.pk])).status_code, 404)
        self.client.force_login(self.host)
        self.client.post(reverse("listings:roommate_delete", args=[post.pk]))
        self.assertFalse(RoommatePost.objects.exists())

    def test_admin_approve_and_reject(self):
        post = make_post(self.host, status=Status.PENDING)
        self.client.force_login(self.admin)
        self.client.post(reverse("listings:admin_roommate_action", args=[post.pk, "approve"]))
        post.refresh_from_db()
        self.assertEqual(post.status, Status.APPROVED)
        self.client.post(reverse("listings:admin_roommate_action", args=[post.pk, "reject"]), {"reason": "Spam"})
        post.refresh_from_db()
        self.assertEqual(post.status, Status.REJECTED)

    def test_pending_post_not_public(self):
        post = make_post(self.host, status=Status.PENDING)
        self.assertNotContains(self.client.get(reverse("listings:find_roommates")), post.title)

    def test_visitor_sees_login_prompt_not_percentage(self):
        make_post(self.host)
        resp = self.client.get(reverse("listings:find_roommates"))
        self.assertContains(resp, "Login to see your compatibility")
        self.assertNotContains(resp, "% Lifestyle Compatibility")

    def test_seeker_sees_personal_compatibility(self):
        # seeker {very_clean, quiet, early_bird, non_smoker} vs post {very_clean, quiet} -> 2/4 = 50%
        make_post(self.host)
        self.client.force_login(self.seeker)
        resp = self.client.get(reverse("listings:find_roommates"))
        self.assertContains(resp, "50% Lifestyle Compatibility")

    def test_seeker_without_lifestyle_gets_not_enough_data(self):
        blank = make_user("blank@example.com", Role.SEEKER)
        make_post(self.host)
        self.client.force_login(blank)
        self.assertContains(self.client.get(reverse("listings:find_roommates")), "Not enough data")

    def test_best_match_sorting(self):
        make_post(self.host, title="Low match", lifestyle_preferences=["social", "night_owl", "smoker"])
        make_post(self.host, title="High match", lifestyle_preferences=["very_clean", "quiet", "early_bird", "non_smoker"])
        make_post(self.host, title="Mid match", lifestyle_preferences=["very_clean", "social"])
        self.client.force_login(self.seeker)
        resp = self.client.get(reverse("listings:find_roommates"), {"sort": "best"})
        titles = [p.title for p in resp.context["page_obj"]]
        self.assertEqual(titles, ["High match", "Mid match", "Low match"])
        self.assertEqual(resp.context["page_obj"][0].compatibility, 100.0)

    def test_budget_and_lifestyle_filters(self):
        make_post(self.host, title="Cheap quiet", budget_share=5000, lifestyle_preferences=["quiet"])
        make_post(self.host, title="Dear social", budget_share=15000, lifestyle_preferences=["social"])
        resp = self.client.get(reverse("listings:find_roommates"), {"max_budget": 8000, "lifestyle": ["quiet"]})
        self.assertContains(resp, "Cheap quiet")
        self.assertNotContains(resp, "Dear social")

    def test_pagination_nine_per_page(self):
        for i in range(10):
            make_post(self.host, title=f"Post {i}")
        resp = self.client.get(reverse("listings:find_roommates"))
        self.assertEqual(len(resp.context["page_obj"]), 9)


# ------------------------------------------------------------------ Messaging
class MessagingTests(TestCase):
    def setUp(self):
        self.host = make_user("host@example.com", Role.HOST)
        self.seeker = make_user("seeker@example.com", Role.SEEKER)
        self.stranger = make_user("stranger@example.com", Role.SEEKER)
        self.listing = make_listing(self.host)

    def start(self):
        self.client.force_login(self.seeker)
        self.client.post(reverse("listings:message_room_host", args=[self.listing.pk]))
        return Conversation.objects.get()

    def test_seeker_starts_conversation_once(self):
        convo = self.start()
        self.client.post(reverse("listings:message_room_host", args=[self.listing.pk]))
        self.assertEqual(Conversation.objects.count(), 1)
        self.assertEqual((convo.seeker, convo.host), (self.seeker, self.host))

    def test_send_receive_reply_and_unread(self):
        convo = self.start()
        url = reverse("listings:conversation", args=[convo.pk])
        self.client.post(url, {"body": "Is the room still available?"})
        self.assertEqual(Message.objects.count(), 1)
        self.assertEqual(unread_count(self.host), 1)
        self.assertEqual(unread_count(self.seeker), 0)

        self.client.force_login(self.host)
        resp = self.client.get(url)
        self.assertContains(resp, "Is the room still available?")
        self.assertEqual(unread_count(self.host), 0)  # opening marks as read
        self.client.post(url, {"body": "Yes, it is."})
        self.assertEqual(unread_count(self.seeker), 1)
        self.assertEqual(Message.objects.count(), 2)

        self.client.force_login(self.seeker)
        self.client.get(url)
        self.assertEqual(unread_count(self.seeker), 0)

    def test_inbox_lists_conversation_with_unread(self):
        convo = self.start()
        self.client.post(reverse("listings:conversation", args=[convo.pk]), {"body": "Hello there"})
        self.client.force_login(self.host)
        resp = self.client.get(reverse("listings:inbox"))
        self.assertContains(resp, "Hello there")
        self.assertContains(resp, "1 unread")

    def test_empty_message_rejected(self):
        convo = self.start()
        self.client.post(reverse("listings:conversation", args=[convo.pk]), {"body": "   "})
        self.assertEqual(Message.objects.count(), 0)

    def test_stranger_cannot_read_or_post(self):
        convo = self.start()
        url = reverse("listings:conversation", args=[convo.pk])
        self.client.force_login(self.stranger)
        self.assertEqual(self.client.get(url).status_code, 403)
        self.assertEqual(self.client.post(url, {"body": "intrude"}).status_code, 403)
        self.assertEqual(Message.objects.count(), 0)

    def test_host_cannot_start_conversation(self):
        self.client.force_login(self.host)
        resp = self.client.post(reverse("listings:message_room_host", args=[self.listing.pk]))
        self.assertEqual(resp.status_code, 403)

    def test_roommate_post_conversation(self):
        post = make_post(self.host)
        self.client.force_login(self.seeker)
        self.client.post(reverse("listings:message_roommate_host", args=[post.pk]))
        self.assertEqual(Conversation.objects.get().roommate_post, post)


# ------------------------------------------------------------------ Saved listings
class SavedListingTests(TestCase):
    def setUp(self):
        self.host = make_user("host@example.com", Role.HOST)
        self.seeker = make_user("seeker@example.com", Role.SEEKER)
        self.listing = make_listing(self.host)
        self.client.force_login(self.seeker)

    def test_save_and_unsave(self):
        self.client.post(reverse("listings:save_listing", args=[self.listing.pk]))
        self.assertEqual(SavedListing.objects.count(), 1)
        self.assertContains(self.client.get(reverse("listings:saved_list")), self.listing.title)
        self.client.post(reverse("listings:unsave_listing", args=[self.listing.pk]))
        self.assertEqual(SavedListing.objects.count(), 0)

    def test_saving_twice_makes_no_duplicate(self):
        self.client.post(reverse("listings:save_listing", args=[self.listing.pk]))
        self.client.post(reverse("listings:save_listing", args=[self.listing.pk]))
        self.assertEqual(SavedListing.objects.count(), 1)

    def test_database_unique_constraint(self):
        SavedListing.objects.create(user=self.seeker, listing=self.listing)
        with self.assertRaises(IntegrityError), transaction.atomic():
            SavedListing.objects.create(user=self.seeker, listing=self.listing)

    def test_host_cannot_save(self):
        self.client.force_login(self.host)
        self.assertEqual(self.client.post(reverse("listings:save_listing", args=[self.listing.pk])).status_code, 403)

    def test_cannot_save_unapproved_listing(self):
        pending = make_listing(self.host, status=Status.PENDING)
        resp = self.client.post(reverse("listings:save_listing", args=[pending.pk]))
        self.assertEqual(resp.status_code, 404)


# ------------------------------------------------------------------ Room alerts
class RoomAlertTests(TestCase):
    def setUp(self):
        self.host = make_user("host@example.com", Role.HOST)
        self.seeker = make_user("seeker@example.com", Role.SEEKER)
        self.other = make_user("other@example.com", Role.SEEKER)
        self.admin = User.objects.create_superuser("admin@example.com", PW, name="Admin")

    def test_create_edit_toggle_delete(self):
        self.client.force_login(self.seeker)
        self.client.post(reverse("listings:alert_create"),
                         {"city": "Butwal", "room_type": "SINGLE", "max_rent": 10000,
                          "gender_preference": "M", "is_active": "on"})
        alert = RoomAlert.objects.get()
        self.assertEqual((alert.user, alert.max_rent, alert.is_active), (self.seeker, 10000, True))
        self.client.post(reverse("listings:alert_edit", args=[alert.pk]),
                         {"city": "Pokhara", "room_type": "", "max_rent": "", "gender_preference": ""})
        alert.refresh_from_db()
        self.assertEqual(alert.city, "Pokhara")
        self.assertFalse(alert.is_active)  # checkbox not sent -> off
        self.client.post(reverse("listings:alert_toggle", args=[alert.pk]))
        alert.refresh_from_db()
        self.assertTrue(alert.is_active)
        self.client.post(reverse("listings:alert_delete", args=[alert.pk]))
        self.assertFalse(RoomAlert.objects.exists())

    def test_cannot_touch_other_users_alert(self):
        alert = RoomAlert.objects.create(user=self.seeker, city="Butwal")
        self.client.force_login(self.other)
        self.assertEqual(self.client.post(reverse("listings:alert_delete", args=[alert.pk])).status_code, 404)
        self.assertEqual(self.client.get(reverse("listings:alert_edit", args=[alert.pk])).status_code, 404)

    def test_matching_rules(self):
        listing = make_listing(self.host, city="Butwal", rent=8000, room_type="SINGLE", gender_preference="M")
        match = RoomAlert.objects.create(user=self.seeker, city="butwal", room_type="SINGLE", max_rent=10000,
                                         gender_preference="M")
        RoomAlert.objects.create(user=self.seeker, city="Pokhara")               # wrong city
        RoomAlert.objects.create(user=self.seeker, max_rent=5000)                # too cheap
        RoomAlert.objects.create(user=self.seeker, room_type="FLAT")             # wrong type
        RoomAlert.objects.create(user=self.seeker, gender_preference="F")        # wrong gender
        RoomAlert.objects.create(user=self.seeker, city="Butwal", is_active=False)  # inactive
        wildcard = RoomAlert.objects.create(user=self.other)                     # no criteria
        self.assertEqual(set(find_matching_alerts(listing)), {match, wildcard})

    def test_approval_sends_email_once(self):
        RoomAlert.objects.create(user=self.seeker, city="Butwal", max_rent=10000)
        listing = make_listing(self.host, status=Status.PENDING, title="Alert-worthy room")
        self.client.force_login(self.admin)
        self.client.post(reverse("listings:admin_listing_action", args=[listing.pk, "approve"]))
        self.assertEqual(len(mail.outbox), 1)
        self.assertEqual(mail.outbox[0].to, ["seeker@example.com"])
        self.assertIn("Alert-worthy room", mail.outbox[0].body)
        self.assertIn(reverse("listings:room_detail", args=[listing.pk]), mail.outbox[0].body)
        # approving again (e.g. after an edit) must not re-send
        self.client.post(reverse("listings:admin_listing_action", args=[listing.pk, "approve"]))
        self.assertEqual(len(mail.outbox), 1)

    def test_no_email_when_nothing_matches(self):
        RoomAlert.objects.create(user=self.seeker, city="Pokhara")
        listing = make_listing(self.host, status=Status.PENDING)
        self.client.force_login(self.admin)
        self.client.post(reverse("listings:admin_listing_action", args=[listing.pk, "approve"]))
        self.assertEqual(len(mail.outbox), 0)
