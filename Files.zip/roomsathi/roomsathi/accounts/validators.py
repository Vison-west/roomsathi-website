import os

from django.core.exceptions import ValidationError

ALLOWED_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp"}
MAX_IMAGE_SIZE = 2 * 1024 * 1024  # 2 MB


def validate_image_file(file):
    """Check extension, size and that Pillow can really open it as an image."""
    ext = os.path.splitext(file.name)[1].lower()
    if ext not in ALLOWED_IMAGE_EXTENSIONS:
        raise ValidationError("Only JPG, PNG or WEBP images are allowed.")
    if file.size > MAX_IMAGE_SIZE:
        raise ValidationError("Image must be 2 MB or smaller.")
    try:
        from PIL import Image
        file.seek(0)
        Image.open(file).verify()
    except Exception:
        raise ValidationError("The uploaded file is not a valid image.")
    finally:
        file.seek(0)
